# Tasks and projects on python OOP Concepts - Almost a circle
